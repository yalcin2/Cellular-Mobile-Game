<?php // hey day

    if(isset($_SERVER['HTTP_X_FORWARDED_PROTO'] )) {
      if (strpos( $_SERVER['HTTP_X_FORWARDED_PROTO'], 'https') !== false) {
        $_SERVER['HTTPS']='on';
      }
    };

    define( 'WP_MEMORY_LIMIT', '128M' );
    define( 'WP_MAX_MEMORY_LIMIT', '256M' );
    define( 'FS_METHOD', 'direct');
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', '360875_7f4b2b8df7fe814bedf86ffb05a5fbe6' );

/** MySQL database username */
define( 'DB_USER', 'easywp_265713' );

/** MySQL database password */
define( 'DB_PASSWORD', 'KPw/6lnyVJVkkAiBuQMUaS3V8YCHpn63SOMflgmCSJE=' );

/** MySQL hostname */
define( 'DB_HOST', 'mysql-cluster-2-mysql-master.database.svc.cluster.local:3306' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'SK>=^&Z`(j:cyO&~b,^ dT~syNJFhI<`)<Dxr3hovfa+b~#N^(f@{L ;X?@8&,!m' );
define( 'SECURE_AUTH_KEY',   'qb%xlgU@ %)Jdw[iz}{t3T&^Q=+~h?>VMH0&wXCGiq_9#(D,;Wq*Q2ylIYNRQ1PY' );
define( 'LOGGED_IN_KEY',     ']fq_,FYPPu#bv[]C`H{y~ TKh@l3DWzfZLwc{&Yw!iFc(jZRuDC{3-n@`<Ho.@||' );
define( 'NONCE_KEY',         ']wT?[(G:1gc(|1Jn~<;4XNNVeOYM/D9/n8N_u=;/ZX@GJj3EWX=Q7k`6A,PGW]4%' );
define( 'AUTH_SALT',         '#~jGg<wMf{=Q:dL>;>M][yA Onv:P-w=WU4yROKNahdT6b0}wCy(@R??A<]I6aMw' );
define( 'SECURE_AUTH_SALT',  '*$;=^cTy QzH7>DrzHw~~48|@ScLb.:VZ(tx^f54dG_;{V]IUW>^)t33DC.^!;Z;' );
define( 'LOGGED_IN_SALT',    'Ua246oi?n|IsgQU0QGFn(*t`+8c4_SL^iaj^~&-dov(N;c623je?Xy <L7L~my/5' );
define( 'NONCE_SALT',        'WOx0J^f%>7hmkg/?qgq`<HlU.m}<f+0z_b$^Pk91M+F24~QGxfm-L_vX8!8+iLTM' );
define( 'WP_CACHE_KEY_SALT', '9&fo14csrzc3#-88#LM$`E:K.hz8tQ8^}6G!!oo9J!Fp:p3Zd2I{#OQs;-Jh|L:a' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
